package id.putraprima.mygoldtracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;

import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItem;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import id.putraprima.mygoldtracker.screen.buy.BuyFragment;
import id.putraprima.mygoldtracker.screen.transactions.TransactionsFragment;
import id.putraprima.mygoldtracker.screen.wallet.WalletFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SmartTabLayout sTabLayout = (SmartTabLayout) findViewById(R.id.viewPagerTab);
        ViewPager vPager = (ViewPager) findViewById(R.id.viewPager);

        FragmentPagerItems pages = new FragmentPagerItems(this);
        pages.add(FragmentPagerItem.of("Wallet", WalletFragment.class));
        pages.add(FragmentPagerItem.of("Transactions", TransactionsFragment.class));
        pages.add(FragmentPagerItem.of("Buy/Sell", BuyFragment.class));

        FragmentPagerItemAdapter adapter = new FragmentPagerItemAdapter(getSupportFragmentManager(), pages);
        vPager.setAdapter(adapter);
        sTabLayout.setViewPager(vPager);
    }
}